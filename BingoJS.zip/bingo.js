// bingo.js

// Global variables
var usedArray = new Array(76);  // Array to track used bingo numbers
var baseArray = [0,0,0,0,0,1,1,1,1,1,2,2,2,2,3,3,3,3,3,4,4,4,4,4];
var number = 0;
var base = 0;

// Document ready event
$(document).ready(function () {
    // Call the init function when the document is ready
    init();

    // jQuery selector action for '#newCard' click
    $('#newCard').click(function () {
        // Reset used numbers array
        resetUsedNumbersArray();
        
        // Generate a new Bingo card
        init();
    });

    // jQuery click event for td elements
    $('td').click(function () {
        var toggle = this.style;
        toggle.backgroundColor = toggle.backgroundColor ? "" : "#333";
        toggle.color = toggle.color ? "" : "#eee";
    });
});

// Function to initialize the Bingo card
function init() {
    // Loop 24 times and call fillCard function
    for (var i = 0; i < 24; i++) {
        fillCard(i);
    }
}

// Function to fill a Bingo card square
function fillCard(i) {
    // Update global variable 'base'
    base = baseArray[i] * 15;
    
    // Update global variable 'number' with a random number in the range of 1-15
    number = base + Math.floor(Math.random() * 15) + 1;
    
    // Check if the number has not been used
    if (!usedArray[number]) {
        // Update the HTML tag element with id "square#"
        $('#square' + i).html(number);

        // Mark the number as used in the array
        usedArray[number] = true;

        // Set background and text color for new game
        var id = "square" + i;
    document.getElementById(id).style.backgroundColor = "#eee";
        document.getElementById(id).style.color = "#333";
    } else {
        // If the number has been used, recursively call fillCard again
        fillCard(i);
    }
}

// Function to reset the used numbers array
function resetUsedNumbersArray() {
    // Loop through the usedArray and set each element to false
    for (var i = 0; i < usedArray.length; i++) {
        usedArray[i] = false;
    }
}
