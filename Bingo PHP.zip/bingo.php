<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bingo</title>
  
  <!-- Include external CSS file for styling -->
  <style>
    <?php include 'bingo.css'; ?>
  </style>
  
  <!-- Include jQuery library -->
  <script type="text/javascript" src="jquery-2.1.0.js"></script>
  
  <!-- JavaScript/jQuery function to update FREE space -->
  <script type="text/javascript">
    function setFree() {
      var row = -1;
      // Iterate through each table row
      $("table tr").each(function() {
        row++;
        var currentRow = $(this);
        // Set the "FREE" text in the center cell of the second row
        if (row == 2) {
          currentRow.find("td:eq(2)").text("FREE");
        }
      });
    }
  </script>
</head>
<body>   
<?php
// Define constants and initialize arrays
define('SIZE', 5);
define('BR', "<br />\n");
$columns = array(
    range(1, 15),
    range(16, 30),
    range(31, 45),
    range(46, 60),
    range(61, 75)
);
$bingo_card = array();

// Generate random Bingo card
for ($i = 0; $i < 5; $i++) {
    $random_keys = array_rand($columns[$i], 5);
    $random_values = array_intersect_key($columns[$i], array_flip($random_keys));
    $bingo_card = array_merge($bingo_card, $random_values);
}

// Output HTML structure for the Bingo card
echo '<h1 class="title">Bingo</h1>'; 
echo '<div id="board">'; 
echo '<table class="container">'; 

// Loop through the 5 rows
for ($i = 0; $i < SIZE; $i++) {
    echo '<tr class="row">'; 
    // Loop through 5 columns in each row
    for ($j = 0; $j < SIZE; $j++) {
        // Output each cell with the corresponding Bingo card value
        echo '<td class="data">' . $bingo_card[$i + $j * 5] . '</td>';
    }

    echo '</tr>'; // Close the <tr> for the row
}

echo '</table>'; // Close the <table>
   
// Call JavaScript function setFree() to update the FREE space
echo '<script type="text/javascript">setFree();</script>';
echo '</div>'; // Close the <div>
?>
</body>
</html>
