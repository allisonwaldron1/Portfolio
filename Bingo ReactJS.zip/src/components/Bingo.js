// Filename: Bingo.jsx (or Bingo.js)

import React from 'react';
import './Bingo.css';

class Bingo extends React.Component {
  constructor(props) {
    super(props);
    this.handleMouseClick = this.handleMouseClick.bind(this);

    // Initialize data and card in the constructor
    const data = this.populateData();
    const card = this.populateCard(data);

    this.state = {
      data: data,
      card: card,
    };
  }

  handleMouseClick(event) {
    event.target.classList.toggle('highlight');
  }

  populateData() {
    const data = [];
    for (let i = 1; i <= 75; i++) {
      data.push(i);
    }
    return data;
  }

  populateCard(data) {
    const numbers = data;
    const card = [];

    // Helper function to check if a number is in the specified range
    const isInRange = (num, start, end) => num >= start && num <= end;

    for (let row = 0; row < 5; row++) {
      for (let col = 0; col < 5; col++) {
        let idx;

        if (row === 2 && col === 2) {
          // Set "FREE" in the middle of the card
          card.push("FREE");
          continue;
        }

        const rangeStart = col * 15 + 1;
        const rangeEnd = (col + 1) * 15;

        idx = rangeStart + Math.floor(Math.random() * (rangeEnd - rangeStart + 1));

        // Ensure the generated number is within the specified range and not already in the card
        while (!isInRange(idx, rangeStart, rangeEnd) || card.includes(idx)) {
          idx = rangeStart + Math.floor(Math.random() * (rangeEnd - rangeStart + 1));
        }

        card.push(idx);
      }
    }

    return card;
  }

  getNumber(idx) {
    const bingoCard = this.state.card;
    const number = bingoCard[idx];
    return number === "FREE" ? number : parseInt(number, 10);
  }

  render() {
    return (
      <div id="bingo-container">
        <div id="board">
          {[0, 1, 2, 3, 4].map((row) => (
            <div className="row" key={row}>
              {[0, 1, 2, 3, 4].map((col) => (
                <div className={`bingo ${this.getNumber(row * 5 + col) === 'FREE' ? 'free' : ''}`} key={row * 5 + col} onClick={this.handleMouseClick}>
                  <span>{this.getNumber(row * 5 + col)}</span>
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>
    );
  }
}

export default Bingo;
